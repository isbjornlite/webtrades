const { ema, rsi, atr } = require('../indicators');

function runRsi2Engine(entryBars, trendBars, PARAMS) {
  const n = entryBars.length;
  const closes = entryBars.map((b) => b.close);
  const rsiArr = rsi(closes, PARAMS.rsiPeriod);
  const atrArr = atr(entryBars, PARAMS.atrPeriod);

  const trendCloses = trendBars.map((b) => b.close);
  const trendFast = ema(trendCloses, PARAMS.trendEmaFast);
  const trendSlow = ema(trendCloses, PARAMS.trendEmaSlow);
  let trendPtr = 0;
  const trendDirAt = new Array(n).fill(null);
  for (let i = 0; i < n; i++) {
    while (trendPtr + 1 < trendBars.length && trendBars[trendPtr + 1].time <= entryBars[i].time) trendPtr++;
    if (trendFast[trendPtr] != null && trendSlow[trendPtr] != null) {
      if (trendFast[trendPtr] > trendSlow[trendPtr]) trendDirAt[i] = 'long';
      else if (trendFast[trendPtr] < trendSlow[trendPtr]) trendDirAt[i] = 'short';
    }
  }

  let balance = PARAMS.startBalance;
  const closedTrades = [];
  let nextSearchIdx = 0;
  const warmup = Math.max(PARAMS.rsiPeriod, PARAMS.atrPeriod, 5) + 1;

  for (let i = warmup; i < n; i++) {
    if (i < nextSearchIdx) continue;
    if (rsiArr[i] == null || atrArr[i] == null) continue;
    const dir = trendDirAt[i];
    if (!dir) continue;

    let direction = null;
    if (dir === 'long' && rsiArr[i] < PARAMS.rsiOversold) direction = 'long';
    if (dir === 'short' && rsiArr[i] > PARAMS.rsiOverbought) direction = 'short';
    if (!direction) continue;

    const entryBar = entryBars[i];
    const entry = entryBar.close;
    const slDist = Math.max(PARAMS.slATR * atrArr[i], entry * PARAMS.minSlDistancePct);
    const sl = direction === 'long' ? entry - slDist : entry + slDist;
    const riskAmount = balance * PARAMS.riskPct;
    const size = riskAmount / slDist;

    let exitPrice = null, exitReason = null, exitTime = null, exitIdx = n;
    for (let k = i + 1; k < n; k++) {
      const b = entryBars[k];
      if (direction === 'long') {
        if (b.low <= sl) { exitPrice = sl; exitReason = 'Stop loss'; exitTime = b.time; exitIdx = k; break; }
        if (rsiArr[k] != null && rsiArr[k] >= PARAMS.rsiExitLong) { exitPrice = b.close; exitReason = 'RSI normalisert'; exitTime = b.time; exitIdx = k; break; }
      } else {
        if (b.high >= sl) { exitPrice = sl; exitReason = 'Stop loss'; exitTime = b.time; exitIdx = k; break; }
        if (rsiArr[k] != null && rsiArr[k] <= PARAMS.rsiExitShort) { exitPrice = b.close; exitReason = 'RSI normalisert'; exitTime = b.time; exitIdx = k; break; }
      }
    }

    if (exitPrice != null) {
      const pnl = direction === 'long' ? size * (exitPrice - entry) : size * (entry - exitPrice);
      balance += pnl;
      closedTrades.push({
        direction, entryTime: entryBar.time, entry, sl, size, riskAmount,
        exitPrice, exitReason, exitTime, pnl, rMultiple: pnl / riskAmount,
      });
    } else {
      closedTrades.push({
        direction, entryTime: entryBar.time, entry, sl, size, riskAmount,
        exitPrice: null, exitReason: 'Åpen ved slutten av datasettet', exitTime: null, pnl: 0, rMultiple: 0,
      });
    }

    nextSearchIdx = exitIdx + 1;
  }

  return { balance, closedTrades };
}

module.exports = { runRsi2Engine };
