const PARAMS = {
  symbols: [
    { key: 'XAUUSD', label: 'Gold (XAU/USD)', td: 'XAU/USD' },
    { key: 'BTCUSD', label: 'Bitcoin (BTC/USD)', td: 'BTC/USD' },
    { key: 'SPY', label: 'S&P 500 ETF (SPY)', td: 'SPY' },
    { key: 'XAGUSD', label: 'Silver (XAG/USD)', td: 'XAG/USD' },
  ],
  trendTimeframe: '4h',   // same higher-timeframe trend filter as Trend Pullback / Squeeze
  trendEmaFast: 50,
  trendEmaSlow: 200,
  rsiPeriod: 2,
  rsiOversold: 10,   // long trigger in an uptrend
  rsiOverbought: 90,  // short trigger in a downtrend
  rsiExitLong: 60,    // exit long once RSI(2) recovers to here
  rsiExitShort: 40,   // exit short once RSI(2) drops to here
  atrPeriod: 14,
  slATR: 2.0,          // hard stop if the mean-reversion trade goes wrong
  minSlDistancePct: 0.003,
  riskPct: 0.01,
  startBalance: 10000,
  outputsize: 5000,
};

const TIMEFRAMES = [
  { key: '15min', label: '15 min', td: '15min' },
  { key: '30min', label: '30 min', td: '30min' },
  { key: '1h', label: '1 time', td: '1h' },
];

module.exports = { PARAMS, TIMEFRAMES };
